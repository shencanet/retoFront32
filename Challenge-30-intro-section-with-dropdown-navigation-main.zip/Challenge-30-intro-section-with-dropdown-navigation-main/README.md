## Reto 30 - Intro section with dropdown navigation

![Design preview for the Intro section with dropdown navigation coding challenge](./design/desktop-preview.jpg)


## También puedes seguirme en mis redes sociales:


✅YouTube: https://www.youtube.com/CodingTube

✅TikTok: https://www.tiktok.com/@codingtube

✅WEB: https://coding-tube.com/

✅Twitter: https://twitter.com/CodingTube

✅Discord: https://discord.gg/tasEBrh8Zw

✅Twitch: https://www.twitch.tv/codingtube

✅Facebook: https://www.facebook.com/groups/codingtubers

►CURSOS:

📕HTML5: https://bit.ly/CodingHTML01

📘CSS3: https://bit.ly/CodingCSS01

📙Javascript: http://bit.ly/CodingJS01

📔 Tailwind: http://bit.ly/Tailwind01

►LISTAS DE REPRODUCCIÓN RECOMENDADAS:

📒Etiquetas HTML: https://bit.ly/HTMLShorts

📗Todos los retos frontend: https://bit.ly/CodingRetos
